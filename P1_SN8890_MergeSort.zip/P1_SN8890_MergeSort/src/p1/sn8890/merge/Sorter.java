/* this is a class that deals with generic merge sorting
 * The class name is called Sorter and contains a public method called sort 
 *and private methods called merge and mergesort respectively. These methods use 
 *recursion.
 */

package p1.sn8890.merge;

public class Sorter  {
	
	/* This method sorts a generic array by calling the mergesort private 
	 * recursively
	 * @param(T[] items)
	 * does not return anything but rather sorts the elements using mergesort algorithm
	 */
	
	public static <T extends Comparable <T>> void sort(T[] items ) {
		
		mergesort(items , 0, items.length-1);
	
	}
	
	/* This method merges the elements into one array after it's have been sorted by 
	 * creating a temp array and copying the elements into the orginial array
	 * @param(T[] array, int a, int mid, int c)
	 * does not return anything but rather merges the elements into one array after they have been sorted
	 */
		 
	 @SuppressWarnings("unchecked") private static <T extends Comparable<T>> void  merge(T[] array, int a, int mid, int c) {

			Object[] temparray = new Object[c-a+1]; 
			int i = a;
			int j = mid+1;
			int k = 0;
			while (i <= mid && j <= c) {
			    if (array[i].compareTo(array[j])<=0)
				temparray[k] = array[i++];
			    else
				temparray[k] = array[j++];
			    k++;
			}
			if (i <= mid && j > c) {
			    while (i <= mid) 
				temparray[k++] = array[i++];
			} else {
			    while (j <= c)
				temparray[k++] = array[j++];
			}
			for (k = 0; k < temparray.length; k++) {
			    array[k+a] = (T)(temparray[k]); 
			}
		    }
	 
	 /* This method sorts the elements by finding the middle element and dividing the 
	  * array into two subarrays  
		 * @param(T[] items)
		 * does not return anything but rather sorts the elements using mergesort algorithm
		 */
		    
		private static <T extends Comparable<T>> void mergesort(T [] arry, int a, int c) { 
	        if (a < c) { 
	           
	            var b=(c+a)/2; 
	  
	             
	            mergesort(arry, a, b); 
	            mergesort(arry , b+1, c); 
	            merge(arry, a, b, c); 
	        } 
	    }
		
		
		


}

