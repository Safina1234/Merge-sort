/* this is a Junit testing class which tests my sort
 * method using different generic types it test when the array
 * is empty, with one variable sorted and unsorted elements in
 * an array
 * To test it properly I had to specify the number of elements of the 
 * array and then add the elements by assigning the elements to the respective
 * Indices and then test the sort method respectively. To test the array for types other
 * than the regular primitive types I had create a class first and then create a compareTo
 * method for that class. For example the Person class that I created to make sure the 
 * sort method can pass any type.
 */
package p1.sn8890.merge;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Arrays;

import org.junit.jupiter.api.Test;

public class SorterTest {

	// testing with zero elements in an Integer array
	@Test
	void test0() {
		Integer [] nums = new Integer[0];
		Integer [] exp = nums.clone();
		
		Sorter.sort(nums);
		
		assertArrayEquals(exp, nums);
	}
	
	// Testing with one element in an Integer array
	@SuppressWarnings("deprecation")
	@Test
	void test1() {
		Integer [] nums = new Integer[1];
		nums[0]= new Integer(42);
		
		Integer [] exp = nums.clone();
		
		Sorter.sort(nums);
		
		assertArrayEquals(exp, nums);
	}
	
	
// testing with sorted Character array with character elements	
	@SuppressWarnings("deprecation")
	@Test
	void test2InOrder() {
		Character [] characters =  new Character [4];
		
		characters[0]= new Character('a');
		characters[1]= new Character('b');
		characters[2]= new Character('c');
		characters[3]= new Character('d');
		
		
		Character [] exp = characters.clone();
		
		Sorter.sort(characters);
		
		assertArrayEquals(exp, characters);
	}

	// testing a sorted Integer array with Integer elements
	@SuppressWarnings("deprecation")
	@Test
	void test3InOrder() {
		Integer [] nums =  new Integer[4];
		
		nums[0]= new Integer (12);
		nums[1]= new Integer(13);
		nums[2]= new Integer(14);
		nums[3]= new Integer(15);
		Integer[] exp = nums.clone();
		
		Sorter.sort(nums);
		
		assertArrayEquals(exp, nums);
	}
	
	// Testing an unsorted array of type Person with Person elements
	
	@Test
	void test2NotInOrder() {
		Person [] person= new Person[4];
		
		person[0]= new Person("Steve",12);
		person[1]= new Person("Safina",17);
		person[2]= new Person("Pops",80);
		person[3]= new Person("Apple",90);
		
		Person[] exp = person.clone();
		Sorter.sort(person);
		
		
		
		Arrays.sort(exp);
		assertArrayEquals(exp, person);
	}
	
	// Testing an unsorted String array with String elements
	
	@Test
	void test3NotInOrder() {
		String [] fruit= new String[4];
		
		fruit[0]= new String("Apple");
		fruit[1]= new String("Banana");
		fruit[2]= new String("Watermelon");
		fruit[3]= new String("Avacado");

		String[] exp = fruit.clone();
		Sorter.sort(fruit);
		
		
		
		Arrays.sort(exp);
		assertArrayEquals(exp, fruit);
	}

}
