/* This is a person class I created to test my generic merge sort method
 * It creates a person object and the merge sort will sort the 
 * person object by Name first instead of age by using the compareTo 
 * method implemented in the Person class.
 */


package p1.sn8890.merge;

public class Person implements Comparable <Person> {

	// instance variables
	private String name;
	private int age;
	
	//Constructor for person object
	public Person(String name, int age) {
		
		this.name=name;
		this.age=age;
	}

	
	@Override
	public int compareTo(Person o) {
		// TODO Auto-generated method stub
		
		 int output=0;
		
		if(this.name.compareToIgnoreCase(o.name)>0) {
			
			output=1;
		}
		
		else if (this.name.compareToIgnoreCase(o.name)<0) {
			
			output=-1;
		}
			
			else if
					(this.age>o.age) {
					
					output=1;
			}
		
			else if (this.age<o.age) {
				
				output=-1;
			}
		
			else
				
				output=0;
		
		return output;
			
		}
// String representation of person object
	@Override
	public String toString() {
		return "Person [name=" + name + ", age=" + age + "]";
	}
	
	
	
			
		}
	
	
	

